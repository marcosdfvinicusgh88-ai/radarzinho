/**
 * Cliente do backend leve (server/).
 * ------------------------------------------------------------
 * Um único ponto de configuração: RADAR_API_BASE_URL.
 * - Em desenvolvimento local, aponta para http://localhost:3001
 * - Em produção, troque pela URL onde o backend (pasta /server) estiver publicado.
 *
 * Se o backend estiver fora do ar ou não configurado, os formulários
 * caem graciosamente para o WhatsApp/e-mail (ver fallback abaixo),
 * então o site nunca fica "quebrado" por causa do backend.
 * ------------------------------------------------------------
 */
const RADAR_API_BASE_URL =
  (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')
    ? 'http://localhost:3001'
    : 'https://api.SEU-DOMINIO-AQUI.com.br'; // <- troque depois do deploy do backend

async function radarApiPost(path, payload) {
  const res = await fetch(`${RADAR_API_BASE_URL}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  let data = {};
  try { data = await res.json(); } catch { /* resposta sem corpo JSON */ }
  if (!res.ok || data.ok === false) {
    throw new Error(data.erro || 'Não foi possível enviar agora.');
  }
  return data;
}

/** Dispara um evento anônimo de uso (ex: moldura gerada). Nunca falha de forma visível. */
function radarTrackEvent(tipo, meta) {
  radarApiPost('/api/eventos', { tipo, meta }).catch(() => { /* tracking é best-effort */ });
}

function formToObject(form) {
  const obj = {};
  new FormData(form).forEach((v, k) => { obj[k] = v; });
  return obj;
}

function setFormStatus(el, message, kind) {
  if (!el) return;
  el.textContent = message;
  el.classList.remove('is-success', 'is-error');
  if (kind) el.classList.add(kind === 'success' ? 'is-success' : 'is-error');
}

/**
 * Conecta um <form> ao backend. Em caso de erro/indisponibilidade,
 * usa fallbackHref (ex: link de WhatsApp/mailto) como alternativa.
 */
function wireForm({ formId, statusId, endpoint, successMessage, fallbackHref, fallbackLabel }) {
  const form = document.getElementById(formId);
  const status = document.getElementById(statusId);
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = form.querySelector('button[type="submit"]');
    const data = formToObject(form);

    if (btn) btn.disabled = true;
    setFormStatus(status, 'Enviando...', null);

    try {
      await radarApiPost(endpoint, data);
      setFormStatus(status, successMessage, 'success');
      form.reset();
    } catch (err) {
      const linkHtml = fallbackHref
        ? ` Tente pelo <a href="${fallbackHref}" target="_blank" rel="noopener">${fallbackLabel || 'WhatsApp'}</a>.`
        : '';
      if (status) {
        status.innerHTML = `Não conseguimos enviar agora.${linkHtml}`;
        status.classList.remove('is-success');
        status.classList.add('is-error');
      }
    } finally {
      if (btn) btn.disabled = false;
    }
  });
}

document.addEventListener('radar:content-ready', (e) => {
  const candidato = (e.detail && e.detail.candidato) || {};
  const contato = (e.detail && e.detail.contato) || {};
  wireForm({
    formId: 'formVoluntario',
    statusId: 'volStatus',
    endpoint: '/api/voluntarios',
    successMessage: 'Recebemos seus dados! Em breve a coordenação entra em contato. 🙌',
    fallbackHref: candidato.grupoVoluntariosWhatsapp,
    fallbackLabel: 'grupo do WhatsApp',
  });
  wireForm({
    formId: 'formContato',
    statusId: 'ctStatus',
    endpoint: '/api/contato',
    successMessage: 'Mensagem enviada! Vamos responder o quanto antes.',
    fallbackHref: candidato.grupoVoluntariosWhatsapp,
    fallbackLabel: 'nosso WhatsApp',
  });
});
